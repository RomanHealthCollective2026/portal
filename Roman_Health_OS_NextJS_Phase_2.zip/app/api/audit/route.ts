import { NextRequest, NextResponse } from "next/server";
import { auth0 } from "@/lib/auth0";
import { writeAuditEvent } from "@/lib/audit";
import { z } from "zod";
const schema=z.object({action:z.string().min(1),entityType:z.string().min(1),entityId:z.string().optional(),patientId:z.string().optional(),metadata:z.record(z.string(),z.unknown()).optional()});
export async function POST(req:NextRequest){const session=await auth0.getSession();if(!session)return NextResponse.json({error:"unauthorized"},{status:401});const parsed=schema.safeParse(await req.json());if(!parsed.success)return NextResponse.json({error:parsed.error.flatten()},{status:400});const event=await writeAuditEvent({...parsed.data,actorUserId:session.user.sub,ipAddress:req.headers.get("x-forwarded-for")??undefined,userAgent:req.headers.get("user-agent")??undefined});return NextResponse.json({id:event.id},{status:201})}