import { requireSession } from "@/lib/rbac";
import DashboardShell from "@/components/DashboardShell";

export default async function DashboardPage() {
  const session = await requireSession();
  const claim = process.env.AUTH0_ROLE_CLAIM ?? "https://romanhealthcollective.com/roles";
  const roles = (((session.user as Record<string, unknown>)[claim] ?? ["patient"]) as string[]);
  return <DashboardShell user={{ name: session.user.name ?? "Portal User", email: session.user.email ?? "", roles }} />;
}