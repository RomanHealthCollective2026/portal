import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return <main className="landing"><section className="landingPanel"><Image src="/roman-logo.png" alt="Roman Health Collective" width={260} height={260} priority/><p className="eyebrow">Roman Health OS</p><h1>One portal. Every detail. Exceptional recovery.</h1><p>Securely coordinate patients, physicians, partners, transportation, recovery suites, concierge services, billing, and clinical interoperability.</p><div className="actions"><Link className="primary" href="/auth/login">Secure Login</Link><Link className="secondary" href="/dashboard">View Dashboard</Link></div><small>Prototype environment — do not enter real patient information until production controls and BAAs are complete.</small></section></main>;
}