import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Roman Health OS", description: "Luxury recovery coordination platform" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}