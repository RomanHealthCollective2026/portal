import { redirect } from "next/navigation";
import { auth0 } from "@/lib/auth0";

export const ROLES = ["patient", "physician", "coordinator", "partner", "admin"] as const;
export type AppRole = (typeof ROLES)[number];

export async function requireSession() {
  const session = await auth0.getSession();
  if (!session) redirect("/auth/login");
  return session;
}

export async function requireRole(...allowed: AppRole[]) {
  const session = await requireSession();
  const claim = process.env.AUTH0_ROLE_CLAIM ?? "https://romanhealthcollective.com/roles";
  const roles = ((session.user as Record<string, unknown>)[claim] ?? []) as string[];
  if (!allowed.some((role) => roles.includes(role))) redirect("/unauthorized");
  return { session, roles };
}

export function hasPermission(user: Record<string, unknown>, permission: string) {
  const claim = process.env.AUTH0_PERMISSION_CLAIM ?? "permissions";
  const permissions = (user[claim] ?? []) as string[];
  return permissions.includes(permission);
}