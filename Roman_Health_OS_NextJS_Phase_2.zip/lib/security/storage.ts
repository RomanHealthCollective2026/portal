import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3 = new S3Client({ region: process.env.AWS_REGION });

export async function createEncryptedUploadUrl(key: string, contentType: string) {
  if (!process.env.AWS_S3_BUCKET || !process.env.AWS_KMS_KEY_ID) throw new Error("Encrypted storage is not configured");
  const command = new PutObjectCommand({
    Bucket: process.env.AWS_S3_BUCKET,
    Key: key,
    ContentType: contentType,
    ServerSideEncryption: "aws:kms",
    SSEKMSKeyId: process.env.AWS_KMS_KEY_ID
  });
  return getSignedUrl(s3, command, { expiresIn: 300 });
}

export async function createEncryptedDownloadUrl(key: string) {
  if (!process.env.AWS_S3_BUCKET) throw new Error("AWS_S3_BUCKET is not configured");
  return getSignedUrl(s3, new GetObjectCommand({ Bucket: process.env.AWS_S3_BUCKET, Key: key }), { expiresIn: 120 });
}