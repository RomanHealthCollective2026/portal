import { KMSClient, EncryptCommand, DecryptCommand } from "@aws-sdk/client-kms";

const kms = new KMSClient({ region: process.env.AWS_REGION });

export async function encryptField(plaintext: string): Promise<string> {
  if (!process.env.AWS_KMS_KEY_ID) throw new Error("AWS_KMS_KEY_ID is not configured");
  const result = await kms.send(new EncryptCommand({ KeyId: process.env.AWS_KMS_KEY_ID, Plaintext: Buffer.from(plaintext) }));
  if (!result.CiphertextBlob) throw new Error("KMS encryption failed");
  return Buffer.from(result.CiphertextBlob).toString("base64");
}

export async function decryptField(ciphertext: string): Promise<string> {
  const result = await kms.send(new DecryptCommand({ CiphertextBlob: Buffer.from(ciphertext, "base64") }));
  if (!result.Plaintext) throw new Error("KMS decryption failed");
  return Buffer.from(result.Plaintext).toString("utf8");
}