export type NotificationInput = { channel: "sms" | "email"; to: string; subject?: string; message: string };

export async function sendNotification(input: NotificationInput) {
  if (input.channel === "sms") {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    if (!sid || !token) throw new Error("Twilio is not configured");
    const body = new URLSearchParams({ To: input.to, From: process.env.TWILIO_FROM_NUMBER ?? "", Body: input.message });
    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, { method: "POST", headers: { Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded" }, body });
    if (!response.ok) throw new Error(`Twilio failed: ${response.status}`);
    return response.json();
  }
  if (!process.env.SENDGRID_API_KEY) throw new Error("SendGrid is not configured");
  const response = await fetch("https://api.sendgrid.com/v3/mail/send", { method: "POST", headers: { Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ personalizations: [{ to: [{ email: input.to }] }], from: { email: process.env.SENDGRID_FROM_EMAIL }, subject: input.subject ?? "Roman Health Collective Update", content: [{ type: "text/plain", value: input.message }] }) });
  if (!response.ok) throw new Error(`SendGrid failed: ${response.status}`);
  return { accepted: true };
}