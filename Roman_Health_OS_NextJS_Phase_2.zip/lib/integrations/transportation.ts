export type TransportationJobInput = { patientId: string; pickupAt: string; pickupAddress: string; dropoffAddress: string; vehicleClass: string; notes?: string };

export async function createTransportationJob(input: TransportationJobInput) {
  if ((process.env.TRANSPORT_PROVIDER ?? "mock") === "mock") return { id: `mock_${crypto.randomUUID()}`, status: "PENDING", ...input };
  const response = await fetch(`${process.env.TRANSPORT_API_BASE_URL}/jobs`, { method: "POST", headers: { Authorization: `Bearer ${process.env.TRANSPORT_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify(input) });
  if (!response.ok) throw new Error(`Transportation provider failed: ${response.status}`);
  return response.json();
}