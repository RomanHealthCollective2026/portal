type ZohoToken = { access_token: string; expires_in: number; api_domain?: string };
let cached: { token: string; expiresAt: number; apiDomain: string } | null = null;

async function accessToken() {
  if (cached && cached.expiresAt > Date.now() + 60_000) return cached;
  const url = new URL("/oauth/v2/token", process.env.ZOHO_ACCOUNTS_BASE_URL);
  url.searchParams.set("refresh_token", process.env.ZOHO_REFRESH_TOKEN ?? "");
  url.searchParams.set("client_id", process.env.ZOHO_CLIENT_ID ?? "");
  url.searchParams.set("client_secret", process.env.ZOHO_CLIENT_SECRET ?? "");
  url.searchParams.set("grant_type", "refresh_token");
  const response = await fetch(url, { method: "POST", cache: "no-store" });
  if (!response.ok) throw new Error(`Zoho OAuth failed: ${response.status}`);
  const data = await response.json() as ZohoToken;
  cached = { token: data.access_token, expiresAt: Date.now() + data.expires_in * 1000, apiDomain: data.api_domain ?? process.env.ZOHO_API_BASE_URL ?? "https://www.zohoapis.com" };
  return cached;
}

export async function zohoFetch(path: string, init: RequestInit = {}) {
  const auth = await accessToken();
  const response = await fetch(new URL(path, auth.apiDomain), {
    ...init,
    headers: { Authorization: `Zoho-oauthtoken ${auth.token}`, "Content-Type": "application/json", ...(init.headers ?? {}) },
    cache: "no-store"
  });
  if (!response.ok) throw new Error(`Zoho API ${response.status}: ${await response.text()}`);
  return response.json();
}