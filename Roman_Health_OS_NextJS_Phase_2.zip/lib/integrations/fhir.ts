let tokenCache: { token: string; expiresAt: number } | null = null;

async function getToken() {
  if (tokenCache && tokenCache.expiresAt > Date.now() + 60_000) return tokenCache.token;
  const body = new URLSearchParams({ grant_type: "client_credentials", client_id: process.env.FHIR_CLIENT_ID ?? "", client_secret: process.env.FHIR_CLIENT_SECRET ?? "", scope: process.env.FHIR_SCOPE ?? "" });
  if (process.env.FHIR_AUDIENCE) body.set("audience", process.env.FHIR_AUDIENCE);
  const response = await fetch(process.env.FHIR_TOKEN_URL ?? "", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body, cache: "no-store" });
  if (!response.ok) throw new Error(`FHIR OAuth failed: ${response.status}`);
  const data = await response.json() as { access_token: string; expires_in?: number };
  tokenCache = { token: data.access_token, expiresAt: Date.now() + (data.expires_in ?? 300) * 1000 };
  return data.access_token;
}

export async function fhirFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (!process.env.FHIR_BASE_URL) throw new Error("FHIR_BASE_URL is not configured");
  const token = await getToken();
  const response = await fetch(new URL(path, process.env.FHIR_BASE_URL), { ...init, headers: { Authorization: `Bearer ${token}`, Accept: "application/fhir+json", "Content-Type": "application/fhir+json", ...(init.headers ?? {}) }, cache: "no-store" });
  if (!response.ok) throw new Error(`FHIR request failed ${response.status}: ${await response.text()}`);
  return response.json() as Promise<T>;
}