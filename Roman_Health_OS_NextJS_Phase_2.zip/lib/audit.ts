import { prisma } from "@/lib/prisma";

export type AuditInput = {
  actorUserId?: string;
  action: string;
  entityType: string;
  entityId?: string;
  patientId?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
};

export async function writeAuditEvent(input: AuditInput) {
  return prisma.auditEvent.create({ data: {
    actorUserId: input.actorUserId,
    action: input.action,
    entityType: input.entityType,
    entityId: input.entityId,
    patientId: input.patientId,
    metadata: input.metadata ?? {},
    ipAddress: input.ipAddress,
    userAgent: input.userAgent
  }});
}