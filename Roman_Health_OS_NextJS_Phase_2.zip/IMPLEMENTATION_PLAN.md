# Next Build Phase — Implementation Plan

## Workstream 1: Next.js + TypeScript
- App Router frontend and server route handlers
- Shared luxury design system
- Role-sensitive dashboard shell
- Strict TypeScript and input validation

## Workstream 2: Authentication, MFA, RBAC
- Auth0 Universal Login
- Tenant-level MFA enrollment and challenge policy
- Custom role claim and API permissions
- Server-enforced route and action authorization
- Session timeout and account-status checks

## Workstream 3: Data, APIs, audit, storage
- PostgreSQL on Amazon RDS
- Prisma migration pipeline
- Audit events for PHI view/change/export actions
- AWS S3 SSE-KMS and short-lived signed URLs
- KMS envelope encryption for selected database fields

## Workstream 4: Zoho
- CRM referral create/update synchronization
- Forms signed webhooks into referral intake
- Bookings appointment create/read/update
- Sign template-driven agreements and consents
- Idempotency and reconciliation tables before production launch

## Workstream 5: Clinical and operational integrations
- Vendor-neutral FHIR R4 service layer
- SMART Backend Services or vendor OAuth registration
- Secure messaging with application-layer ciphertext
- Stripe Checkout and signed webhook reconciliation
- Transportation provider adapter interface
- Twilio/SendGrid notifications with consent and quiet-hour policy

## Production gates
1. Confirm legal operating model and whether Roman is a covered entity, business associate, or both by workflow.
2. Execute required BAAs before sending PHI to any vendor.
3. Select the EMR and transportation provider so vendor-specific integration can be completed.
4. Create Zoho custom modules and provide field API names.
5. Provision Auth0, AWS, PostgreSQL, Stripe, Twilio, SendGrid, and vendor sandboxes.
6. Complete threat model, penetration test, restore test, and role-access validation.
