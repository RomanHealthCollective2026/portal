# Roman Health OS — Next.js Integration Foundation

This build converts the portal prototype into a Next.js App Router + TypeScript application and provides the production foundation requested:

- Auth0 authentication entry points, tenant-managed MFA, and RBAC claims
- PostgreSQL + Prisma schema
- API routes and Zod validation
- Append-only-style audit-event service
- AWS KMS field encryption and S3 KMS-encrypted storage helpers
- Zoho CRM, Bookings, and Sign API adapters
- Zoho Forms webhook configuration placeholder
- FHIR R4 OAuth client and Patient endpoint proxy
- Encrypted-message persistence scaffold
- Stripe Checkout
- Transportation adapter
- Twilio SMS and SendGrid email notifications

## Start locally

1. Copy `.env.example` to `.env.local` and populate credentials.
2. Start PostgreSQL: `docker compose up -d`.
3. Install dependencies: `npm install`.
4. Generate Prisma client: `npm run db:generate`.
5. Create the initial migration: `npm run db:migrate -- --name init`.
6. Start: `npm run dev`.

## Auth0 configuration

Create roles: `patient`, `physician`, `coordinator`, `partner`, and `admin`. Configure an Auth0 Post Login Action to add roles to the custom claim defined by `AUTH0_ROLE_CLAIM`. Enable MFA in the Auth0 tenant; use adaptive or always-on MFA based on policy. Enable RBAC for the API and include permissions in access tokens.

## Zoho

The adapters require a server-side refresh token and product scopes. Map the CRM custom module and field API names to your actual Zoho configuration. Zoho Forms should post to a dedicated signed webhook endpoint; the provided environment variable reserves that validation secret, but your form-specific field mapping must be added after the form is created.

## FHIR / EMR

The adapter is vendor-neutral FHIR R4. Each EMR requires app registration, scopes, endpoint URLs, launch context, and sometimes SMART Backend Services configuration. Do not enable write operations until vendor certification, consent policy, data mapping, idempotency, and reconciliation are complete.

## Security / HIPAA readiness

This code is a foundation, not a certification. Before PHI production use complete: BAAs, risk analysis, data-flow inventory, least-privilege IAM, database encryption, private networking, immutable audit retention, backup/restore testing, incident response, vendor due diligence, penetration testing, secure SDLC, access reviews, and legal/compliance review.
